- 查看 python 版本
  pip debug --verbose

* ORM - Pony
  https://www.blog.pythonlibrary.org/2014/07/21/python-101-an-intro-to-pony-orm/
  https://leonh.gitbooks.io/pony-orm/content/4-Relationships.html

* 安裝 TA-Lib 參考
  https://medium.com/ai%E8%82%A1%E4%BB%94/%E7%94%A8-python-%E5%BF%AB%E9%80%9F%E8%A8%88%E7%AE%97-158-%E7%A8%AE%E6%8A%80%E8%A1%93%E6%8C%87%E6%A8%99-26f9579b8f3a
* 下載 whl 檔
  https://www.lfd.uci.edu/~gohlke/pythonlibs/#ta-lib



## 執行python快捷鍵(shortcut)
Ctrl + Alt + N

## visual studio code 執行中文亂碼
https://umin27.medium.com/vs-code%E6%8E%A1%E7%94%A8code-runner%E9%81%87%E5%88%B0%E7%9A%84-output%E4%B8%AD%E6%96%87%E4%BA%82%E7%A2%BC%E5%95%8F%E9%A1%8C-python-55e73edf9d0b
1.settings
2.搜尋Code Runner
3.往下找Edit in settings.json，並點選進入
4.加入"code-runner.runInTerminal": true,


## 環境變數
**python**
C:\Users\joshua.lu\AppData\Local\Programs\Python\Python39\
C:\Users\joshua.lu\AppData\Local\Programs\Python\Python39\Scripts
**Git**
C:\Program Files\Git\cmd

*每股盈餘 ＥＰＳ（Earning Per Share）*
=> 計算公式是：每股盈餘＝本期淨利／流通

*本益比 P/E或PER(Price-to-Earning Ratio)*
=> 股價/EPS，持有幾年可依靠盈餘賺回本
ex: 股價３０元的股票，本益比１４倍；而股價５０元的股票，本益比僅１１倍。
     從本益比的角度來看，後者是比較便宜的，因為你有機會持有１１年就靠著盈餘賺回投入本金

*殖利率 (Dividend yield)*
=> 現金股利/股價
ex: 中華電信來說，103年發放現金股利4.86元 股價98.7元，殖利率 = 4.86/98.7 = 4.92%
買進的股價越低，殖利率就越高
買進的股價越高，殖利率就越低