
import random
from fake_useragent import UserAgent

print(UserAgent().random)
print(random.randint(15, 60))